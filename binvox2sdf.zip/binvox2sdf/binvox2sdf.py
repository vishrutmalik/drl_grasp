import numpy as np
import trimesh # for converting voxel grids to meshes (to import objects into simulators)
# import time # to know how long it takes for the code to run
import os # to walk through directories, to rename files
import sys

# import binvox_rw # to manipulate binvox files
import tools_sdf_generator

# Parses a file of type BINVOX
# Returns a voxel grid, generated using the binvox_rw.py package
def parse_BINVOX_file_into_voxel_grid(filename):
    filereader = open(filename, 'rb')
    # binvox_model = binvox_rw.read_as_3d_array(filereader)
    voxelgrid = binvox_model.data
    return voxelgrid

if __name__ == "__main__":
    
    print("Usage: ")
    print("python binvox2sdf.py <FILEPATH>")
    
    filename = sys.argv[1]
    

    # Generate a folder to store the images
    print("Generating a folder to save the mesh")
    #directory = "./binvox2gazebo_" + str(time.time())
    # Generate a folder with the same name as the input file, without its ".binvox" extension
    currentPathGlobal = os.path.dirname(os.path.abspath(__file__))
    directory = currentPathGlobal + "/" + filename[:-4]
    if not os.path.exists(directory):
        os.makedirs(directory)

    mesh = trimesh.load_mesh(filename)
    

    
    
    print("Computing the center of mass: ")
    center_of_mass = mesh.center_mass
    print(center_of_mass)
    
    print("Computing moments of inertia: ")
    moments_of_inertia = mesh.moment_inertia
    print(moments_of_inertia)  # inertia tensor in meshlab

    print("Generating the STL mesh file")
    trimesh.exchange.export.export_mesh(
        mesh=mesh,
        file_obj=directory + "/mesh.stl",
        file_type="stl"
    )

    print("Generating the SDF file...")
    object_model_name = filename[:-4]
    # mass=1.00

    mass = 1.00

    tools_sdf_generator.generate_model_sdf(
        directory=directory,
        object_name=object_model_name,
        center_of_mass=center_of_mass,
        inertia_tensor=moments_of_inertia,
        mass=mass,
        model_stl_path=directory + "/mesh.stl")
